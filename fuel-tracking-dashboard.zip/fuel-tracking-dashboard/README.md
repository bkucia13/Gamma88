# FuelIQ — Fuel Tracking Dashboard

Connected to Supabase project `xbtyuaxherycfbkauzgn` (Gamma88, us-east-2).

## Run locally
1. Install Node.js 20 or newer.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Run `npm run dev`.
5. Open the local URL printed by Vite.

## Deploy
Import this project into Vercel or Netlify, set the two `VITE_SUPABASE_*` environment variables from `.env.example`, and deploy. Add your deployed URL to Supabase Dashboard → Authentication → URL Configuration (Site URL and redirect URLs).

## Access
Todd's user has been assigned administrator access in `public.admin_users`, but must accept the invitation and establish a password first. This app deliberately has no public sign-up. Create users using Supabase Dashboard → Authentication → Users → Invite user. To give a user access to a customer, insert a row in `customer_memberships` (customer_id, user_id) from the Supabase SQL Editor. Only administrators can create customers and readings. Users can view only assigned customers. No service-role key is needed.

## Calculations
`gallons_saved = baseline_gallons - treated_gallons`
`improvement_pct = gallons_saved / baseline_gallons * 100`
`gross_savings = gallons_saved * fuel_price_per_gallon`
`net_savings = gross_savings - additive_oz * additive_cost_per_oz`
Recommended additive dose = treated gallons / 10, based on 1 oz per 10 gallons. The actual dose entered is stored separately.

Readings must compare equivalent periods, loads, and operating conditions to make savings meaningful. These are comparisons, not verified causal estimates.

## Security
All four tables have RLS enabled. Publishable keys are safe to use in browser apps with correctly configured RLS. Never add a service-role key to frontend environment variables.

## Before production
Test login and customer isolation with two real accounts, configure email templates and redirects, set up backups, and verify billing and Auth settings. Dependencies should be locked with `npm install` and the resulting lockfile committed.
